package com.si.project1.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.si.project1.entity.Admin;
import com.si.project1.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	AdminRepository r;
	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return r.save(admin);
	}

	@Override
	public List<Admin> fetchAdminList() {
		// TODO Auto-generated method stub
		return r.findAll();
	}

	@Override
	public Admin fetchAdminById(Long adminId) {
		// TODO Auto-generated method stub
		return r.findById(adminId).get();
	}

	@Override
	public void deleteAdminById(Long adminId) {
		// TODO Auto-generated method stub
		r.deleteById(adminId);
	}

	 @Override
	   public Admin updateAdmin(Long adminId, Admin admin) {
	       Admin admDB = r.findById(adminId).get();

	       if(Objects.nonNull(admin.getName()) &&
	       !"".equalsIgnoreCase(admin.getName())) {
	           admDB.setName(admin.getName());
	       }

	       if(Objects.nonNull(admin.getPassword()) &&
	               !"".equalsIgnoreCase(admin.getPassword())) {
	           admDB.setPassword(admin.getPassword());
	       }

	       return r.save(admDB);
	   }

}
